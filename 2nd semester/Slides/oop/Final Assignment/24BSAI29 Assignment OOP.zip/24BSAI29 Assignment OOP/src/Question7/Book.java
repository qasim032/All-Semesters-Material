package Question7;

public class Book extends Product{
    protected String authorName;
    protected String Edition;

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
}
