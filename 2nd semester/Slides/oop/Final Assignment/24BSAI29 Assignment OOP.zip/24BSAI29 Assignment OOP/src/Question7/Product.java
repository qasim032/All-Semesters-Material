package Question7;

public class Product {
    protected String Name;
    protected float Price;
    protected String Description;

    public void SetPrice(float Price) {
        this.Price = Price;
    }
}
