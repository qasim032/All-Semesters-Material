package Question3;

 class employee {
    protected String employeeName;
    protected int empId;
    protected double basicSalary;
    public employee(String employeeName, int empId, double basicSalary) {
        this.employeeName = employeeName;
        this.empId = empId;
        this.basicSalary = basicSalary;
    }

}
