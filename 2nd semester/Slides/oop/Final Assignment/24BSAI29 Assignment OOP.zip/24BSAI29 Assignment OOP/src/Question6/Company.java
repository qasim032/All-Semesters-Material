package Question6;

public class Company {
    private int EmpId;
    private String EmpName;
    private String EmpAddress;
    private String EmpDept;
    private int EmpPhone;
    private int EmpAge;

    public Company() {

    }
    public int getEmpId() {return this.EmpId;}
    public String getEmpName() {return this.EmpName;}
    public String getEmpAddress() {return this.EmpAddress;}
    public String getEmpDept() {return this.EmpDept;}
    public int getEmpPhone() {return this.EmpPhone;}
    public int getEmpAge() {return this.EmpAge;}

    public void setEmpId(int empId) {EmpId = empId;}
    public void setEmpName(String empName) {EmpName = empName;}
    public void setEmpAddress(String empAddress) {EmpAddress = empAddress;}
    public void setEmpDept(String empDept) {EmpDept = empDept;}
    public void setEmpPhone(int empPhone) {EmpPhone = empPhone;}
    public void setEmpAge(int empAge) {EmpAge = empAge;}





}
