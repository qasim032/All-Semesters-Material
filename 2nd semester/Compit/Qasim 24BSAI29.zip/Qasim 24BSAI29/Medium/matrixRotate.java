import java.util.Scanner;

public class matrixRotate {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int[][] matrix = new int[3][3];

        for (int i = 0; i <matrix.length;i++){
            for (int j =0;j<matrix.length;j++){
                matrix[i][j]=input.nextInt();

            }
        }
//        for (int i = 0; i <matrix.length;i++){
//            for (int j =0;j< matrix.length;j++){
//                System.out.println(matrix[i][j]);
//            }
//        }

        for(int i = 3;i>0;i--){
            for(int j=0;j>)
        }

        }
    }


