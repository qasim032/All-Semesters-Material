public class ComplaintManagement extends Complaint {

    public void addComplaint(String description, String category, String priority,String date){
        category();
    }
    public void displayAllComplaints(){

    }
    public static void main(String[] args) {
        System.out.println("Please enter description,category ");
        ComplaintManagement Ali = new ComplaintManagement();
        Ali.addComplaint();

    }
}
